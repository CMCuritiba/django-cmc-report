# -*- coding: utf-8 -*-

from cmcreport.lib.views import CMCReportView

#----------------------------------------------------------------------------------------
# Classe teste 
#----------------------------------------------------------------------------------------
class ViewCMCReport(CMCReportView):
	template_name = 'relatorio_test.html'