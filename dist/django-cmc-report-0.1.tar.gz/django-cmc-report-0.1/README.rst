Biblioteca utilitária para geração de relatórios sistemas Django CMC
====================================================================

Biblioteca django que fornece utilitários para geração de relatório aos sistemas da Câmara Municipal de Curitiba

.. image:: https://img.shields.io/badge/built%20with-Cookiecutter%20Django-ff69b4.svg
     :target: https://github.com/pydanny/cookiecutter-django/
     :alt: Built with Cookiecutter Django

.. image:: https://travis-ci.org/CMCuritiba/django-cmc-report.svg?branch=master
    :target: https://travis-ci.org/CMCuritiba/django-cmc-report

.. image:: https://codecov.io/gh/CMCuritiba/django-cmc-report/coverage.svg?branch=master
    :target: https://codecov.io/gh/CMCuritiba/django-cmc-report/


:License: MIT
